
console.log("B18 Market Loaded");
